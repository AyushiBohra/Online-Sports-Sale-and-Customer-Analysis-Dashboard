# PowerBI-DataSet
DataSets used on My YouTube channel
